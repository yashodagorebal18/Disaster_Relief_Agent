# core package init
